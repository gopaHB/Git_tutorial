"""geekysshows URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from django.contrib import admin
# from django.urls import path
# from course import views as cs
# from fees import views as fs
# urlpatterns = [
#     path("admin/", admin.site.urls),
#     path( "learndj/", cs.learn_djange ),
#     path( "learnpy/", cs.learn_python ),
#     path( "learnvar/", cs.learn_var ),
#     path( "learnmath/", cs.learn_math ),
#     path( "learnfromat/", cs.learn_format ),
#     path( "feesdj/", fs.fees_djange ),
#
# ]
##########################

from django.contrib import admin
from django.urls import path, include

from fees import views as fs
urlpatterns = [
    path("admin/", admin.site.urls),
    path( "cor/",include('course.urls' )),
    path( "fe/",include('fees.urls' ) ),

]
####################

#
# from django.contrib import admin
# from django.urls import path,include
# from course import views as cv
# from fees import views as fs
# urlpatterns = [
#     path("admin/", admin.site.urls),
#     path( "cor/",include([
#         path( "learndj/", cv.learn_djange ),
#         path( "learnpy/", cv.learn_python ),
#         path( "learnvar/", cv.learn_var ),
#         path( "learnmath/", cv.learn_math ),
#         path( "learnfromat/", cv.learn_format ),
#     ]) ),
#     path( "fe/",include([
#         path( "feesdj/", fs.fees_djange ),
#         path( "feespy/", fs.fees_djange ),
#     ])),
#
# ]