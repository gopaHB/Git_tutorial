from django.urls import path
from . import views
# from fees import views as fs

urlpatterns = [
    path( "feesdj/",views.fees_djange ),
    path( "feespy/", views.fees_python ),


]