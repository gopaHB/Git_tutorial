from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


# def learn_djange(request):
#     return HttpResponse("Hello Django")
# def learn_python(request):
#     return HttpResponse("<h1> Hello Python</h1>")
#
# def learn_var(request):
#     a="<h1>Hello Sehemaphic </h1>"
#     return HttpResponse(a)
#
# def learn_math(request):
#     a=10+10
#     return HttpResponse(a)
#
# def learn_format(request):
#     a="GeekyShows"
#     return HttpResponse(f'Hello {a}')



#######for rander function

def learn_djange(request):
    coursename={'cname':'React'}
    # return render(request,"course/courseone.html" ,context=coursename)
    # return render( request, "course/courseone.html", {'cname':'AI'} )
    cname='machine learning'
    duration='4 months'
    seats=10
    machine_learning_details={'nm':cname,'du':duration,'se':seats}
    # return render( request, "course/courseone.html", context=machine_learning_details)
    return render( request, "course/courseone.html", machine_learning_details)


def learn_python(request):
    return render(request,"course/coursetwo.html")

def learn_var(request):
    a="<h1>Hello Sehemaphic </h1>"
    return HttpResponse(a)