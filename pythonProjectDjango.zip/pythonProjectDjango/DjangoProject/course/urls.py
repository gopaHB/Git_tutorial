from django.urls import path
from . import views
# from fees import views as fs

urlpatterns = [
    path( "learndj/",views.learn_djange ),
    path( "learnpy/", views.learn_python ),


]