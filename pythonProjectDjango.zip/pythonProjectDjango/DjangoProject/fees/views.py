from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

# def fees_djange(request):
#     return HttpResponse("fees Django")
#
#
# def fees_python(request):
#     return HttpResponse("200")


##########For rander
def fees_djange(request):
    return render(request,"fees/feesone.html")
def fees_python(request):
    return render(request,"fees/feestwo.html")

